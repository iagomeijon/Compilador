package Tabela_auto.Tabela;



import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


public  class  GetProperties {

    public static Properties prop = getProp();

    public static Properties getProp() {
        Properties props = new Properties();
        try {
            FileInputStream file = new FileInputStream("./src/main/java/Tabela_auto/Tabela/config.properties");
            props.load(file);
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
        return props;
    }
}
