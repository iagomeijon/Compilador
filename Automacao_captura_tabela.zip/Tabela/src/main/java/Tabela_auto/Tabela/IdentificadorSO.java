package Tabela_auto.Tabela;
import static Tabela_auto.Tabela.GetProperties.prop;
public class IdentificadorSO {

 public static String identificarSO() {
        String retorno;
        if (System.getProperty("os.name").contains("Windows")) {
            retorno = prop.getProperty("CAMINHO_DRIVER_WIN");
        } else {
           retorno = prop.getProperty("CAMINHO_DRIVER_LINUX");
        }
        
        return retorno;
    }

}
