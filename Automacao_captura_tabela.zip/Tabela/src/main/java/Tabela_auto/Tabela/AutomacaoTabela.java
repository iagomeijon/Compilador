package Tabela_auto.Tabela;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;




public class AutomacaoTabela {
	private static WebDriver driver;

    public static void main(String[] args) throws InterruptedException {
    	 System.setProperty("webdriver.chrome.driver", IdentificadorSO.identificarSO());
         driver = new ChromeDriver();
         driver.get("https://mdaines.github.io/grammophone/");
         Grammar grammar = new Grammar();
         driver.findElement(By.cssSelector("#edit > div > textarea")).clear();
         driver.findElement(By.cssSelector("#edit > div > textarea")).sendKeys(grammar.getGramatica());
         driver.findElement(By.cssSelector("#mode-analyze")).click();
         driver.findElement(By.cssSelector("#parsing > table > tbody > tr:nth-child(3) > td:nth-child(3) > a")).click();
         WebElement table = driver.findElement((By.cssSelector("#table > table")));
         WebElement tbody = table.findElement(By.tagName("tbody"));
         List<WebElement> trs = tbody.findElements(By.tagName("tr"));
         List<WebElement> ths = trs.get(0).findElements(By.tagName("th"));
         for(int i = 1 ; i < trs.size() ; i++){
        	 System.out.println("q" + (i-1) +" = {");
        	 List<WebElement> tds = trs.get(i).findElements(By.tagName("td"));
        	 for(int j = 0 ; j < tds.size() ; j ++){
        		 if(!tds.get(j).getText().equals("")){
        			 String saida = "[";
        			 String text = tds.get(j).getText();
        			 if (tds.get(j).getText().indexOf ("reduce") >= 0) {
        				 	saida = text;
        			 }
        			 else if (tds.get(j).getText().indexOf ("shift") >= 0) {
        				 String aux = text.replaceAll("shift", "\"s\"");
     				 	 text = aux;
     				 	 aux = text.replaceAll("\\(", ",");
     				 	 text = aux;
     				 	 aux = text.replaceAll("\\)", "]");
     				 	 text = aux;
     				 	 saida =  saida + text;
        			 }else{
        				 saida = saida + "\"d\","+text+ "]";
        				 
        			 }
        			 System.out.print("\""+ths.get(j+1).getText() +"\""+ ":" +saida+",");
        		 }
        		 
        	 }
        	 System.out.println(" }");
        	 System.out.println("table.append(q"+(i-1)+")");
         }

    }
}
